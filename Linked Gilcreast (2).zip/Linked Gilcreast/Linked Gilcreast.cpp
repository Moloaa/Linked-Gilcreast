// Linked Gilcreast.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include "ListsHeader.h"
#include "LinkedHeader.h"

using namespace std;

int main()
{
    std::cout << "Hello World! We have linked lists\n"; 
    LinkedList;
    //define clock
    ///start clock 1:06 1/18 live
    {
        clock_t start, end;
        start = clock();

    for (int i = 0; i < 100; i++)
    {
          list.insert(i);
  
              
              std::cout << (end - start) / 1000.00;
          }

    {
    Sleep(4000);
    end = clock;
    list.display();
    
    int len = list.getLength();
    cout << "# of nodes =" len << endl;
    }
}
   

    ////Nylea Gilcreast line 14 shows the clock starting and being defined. Line 29 shows the sleep is set to 4000. And the end clock starts at line 30.