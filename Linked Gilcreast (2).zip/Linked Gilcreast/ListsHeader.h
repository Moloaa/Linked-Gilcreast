#pragma once
#include "LinkedHeader.h"
class LInkedList
{
private:
	int length;
	Node* head;

public:
	LInkedList();
	void insert(int data);
	void display();
	int getLength;
};
