#include "ListsHeader.h"
#include <iostream>
#include"LinkedHeader.h"

LinkedList::LinkedList()
{
	length = 0;
	head = NULL;
}

void LinkedList::insert(int num1)
{
	Node* node = new Node();
	node->data = num1;
	node->next = head;
	head = node;
	length++;
}
void LinkedList::display()
{
	Node* curr = this->head;
	int i = 1;
	while (curr)
	{
		std::cout << "node value =" << i << curr->data;
		curr = curr = > next;
		i++;
	}
}
int LinkedList::getLength(
	{
		return length;
	}
)